import type { CodegenTypes, TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    shouldStartLoadWithLockIdentifier(shouldStart: boolean, lockIdentifier: CodegenTypes.Double): void;
}
declare const _default: Spec;
export default _default;
