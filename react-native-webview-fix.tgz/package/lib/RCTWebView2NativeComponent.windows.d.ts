import React from 'react';
import type { CodegenTypes, HostComponent, ViewProps } from 'react-native';
export type WebViewNativeEvent = Readonly<{
    url: string;
    loading: boolean;
    title: string;
    canGoBack: boolean;
    canGoForward: boolean;
    lockIdentifier: CodegenTypes.Double;
}>;
export type WebViewMessageEvent = Readonly<{
    url: string;
    loading: boolean;
    title: string;
    canGoBack: boolean;
    canGoForward: boolean;
    lockIdentifier: CodegenTypes.Double;
    data: string;
}>;
export type WebViewOpenWindowEvent = Readonly<{
    targetUrl: string;
}>;
export type WebViewHttpErrorEvent = Readonly<{
    url: string;
    loading: boolean;
    title: string;
    canGoBack: boolean;
    canGoForward: boolean;
    lockIdentifier: CodegenTypes.Double;
    description: string;
    statusCode: CodegenTypes.Int32;
}>;
export type WebViewErrorEvent = Readonly<{
    url: string;
    loading: boolean;
    title: string;
    canGoBack: boolean;
    canGoForward: boolean;
    lockIdentifier: CodegenTypes.Double;
    domain?: string;
    code: CodegenTypes.Int32;
    description: string;
}>;
export type WebViewNativeProgressEvent = Readonly<{
    url: string;
    loading: boolean;
    title: string;
    canGoBack: boolean;
    canGoForward: boolean;
    lockIdentifier: CodegenTypes.Double;
    progress: CodegenTypes.Double;
}>;
export type WebViewNavigationEvent = Readonly<{
    url: string;
    loading: boolean;
    title: string;
    canGoBack: boolean;
    canGoForward: boolean;
    lockIdentifier: CodegenTypes.Double;
    navigationType: 'click' | 'formsubmit' | 'backforward' | 'reload' | 'formresubmit' | 'other';
    mainDocumentURL?: string;
}>;
export type ShouldStartLoadRequestEvent = Readonly<{
    url: string;
    loading: boolean;
    title: string;
    canGoBack: boolean;
    canGoForward: boolean;
    lockIdentifier: CodegenTypes.Double;
    navigationType: 'click' | 'formsubmit' | 'backforward' | 'reload' | 'formresubmit' | 'other';
    mainDocumentURL?: string;
    isTopFrame: boolean;
}>;
type ScrollEvent = Readonly<{
    contentInsetTop: CodegenTypes.Double;
    contentInsetBottom: CodegenTypes.Double;
    contentInsetLeft: CodegenTypes.Double;
    contentInsetRight: CodegenTypes.Double;
    contentOffsetX: CodegenTypes.Double;
    contentOffsetY: CodegenTypes.Double;
    contentSizeWidth: CodegenTypes.Double;
    contentSizeHeight: CodegenTypes.Double;
    layoutMeasurementWidth: CodegenTypes.Double;
    layoutMeasurementHeight: CodegenTypes.Double;
    zoomScale?: CodegenTypes.Double;
}>;
export interface NativeProps extends ViewProps {
    testID?: string;
    /**
     * Boolean value that determines whether link handling is enabled.
     * When true, the webview can handle link clicks.
     * @platform windows
     */
    linkHandlingEnabled?: boolean;
    /**
     * Function that is invoked when the `WebView` should open a new window.
     * This happens when the JS calls `window.open('http://someurl', '_blank')`
     * or when the user clicks on a `<a href="http://someurl" target="_blank">` link.
     * @platform windows
     */
    onOpenWindow?: CodegenTypes.DirectEventHandler<WebViewOpenWindowEvent>;
    /**
     * Function that is invoked when the `WebView` responds to a request to load a new resource.
     * @platform windows
     */
    onSourceChanged?: CodegenTypes.DirectEventHandler<WebViewNavigationEvent>;
    cacheEnabled?: CodegenTypes.WithDefault<boolean, true>;
    incognito?: boolean;
    injectedJavaScript?: string;
    injectedJavaScriptBeforeContentLoaded?: string;
    injectedJavaScriptForMainFrameOnly?: CodegenTypes.WithDefault<boolean, true>;
    injectedJavaScriptBeforeContentLoadedForMainFrameOnly?: CodegenTypes.WithDefault<boolean, true>;
    javaScriptCanOpenWindowsAutomatically?: boolean;
    javaScriptEnabled?: CodegenTypes.WithDefault<boolean, true>;
    mediaPlaybackRequiresUserAction?: CodegenTypes.WithDefault<boolean, true>;
    webviewDebuggingEnabled?: boolean;
    messagingEnabled: boolean;
    onLoadingError: CodegenTypes.DirectEventHandler<WebViewErrorEvent>;
    onLoadingFinish: CodegenTypes.DirectEventHandler<WebViewNavigationEvent>;
    onLoadingProgress: CodegenTypes.DirectEventHandler<WebViewNativeProgressEvent>;
    onLoadingStart: CodegenTypes.DirectEventHandler<WebViewNavigationEvent>;
    onHttpError: CodegenTypes.DirectEventHandler<WebViewHttpErrorEvent>;
    onMessage: CodegenTypes.DirectEventHandler<WebViewMessageEvent>;
    onScroll?: CodegenTypes.DirectEventHandler<ScrollEvent>;
    onShouldStartLoadWithRequest: CodegenTypes.DirectEventHandler<ShouldStartLoadRequestEvent>;
    showsHorizontalScrollIndicator?: CodegenTypes.WithDefault<boolean, true>;
    showsVerticalScrollIndicator?: CodegenTypes.WithDefault<boolean, true>;
    newSource: Readonly<{
        uri?: string;
        method?: string;
        body?: string;
        html?: string;
        baseUrl?: string;
    }>;
    sourceHeaders?: string;
    basicAuthCredential?: Readonly<{
        username: string;
        password: string;
    }>;
    userAgent?: string;
    applicationNameForUserAgent?: string;
}
export type WindowsNativeProps = NativeProps;
export interface NativeCommands {
    goBack: (viewRef: React.ElementRef<HostComponent<NativeProps>>) => void;
    goForward: (viewRef: React.ElementRef<HostComponent<NativeProps>>) => void;
    reload: (viewRef: React.ElementRef<HostComponent<NativeProps>>) => void;
    stopLoading: (viewRef: React.ElementRef<HostComponent<NativeProps>>) => void;
    injectJavaScript: (viewRef: React.ElementRef<HostComponent<NativeProps>>, javascript: string) => void;
    requestFocus: (viewRef: React.ElementRef<HostComponent<NativeProps>>) => void;
    postMessage: (viewRef: React.ElementRef<HostComponent<NativeProps>>, data: string) => void;
    loadUrl: (viewRef: React.ElementRef<HostComponent<NativeProps>>, url: string) => void;
    clearCache: (viewRef: React.ElementRef<HostComponent<NativeProps>>, includeDiskFiles: boolean) => void;
}
export declare const Commands: NativeCommands;
export declare const WindowsCommands: NativeCommands;
declare const RCTWebView2: HostComponent<NativeProps>;
export default RCTWebView2;
